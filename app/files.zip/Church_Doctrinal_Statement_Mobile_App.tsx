import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Home, BookOpen, Users, User, Play, CheckCircle, Share2, Bookmark, Zap, Clock, Book, Award, Settings, Bell, Heart, Star, Download, Volume2 } from 'lucide-react';

// Color Palette
const colors = {
  darkBrown: '#4A3A28',
  mediumBrown: '#7B5E3C',
  lightBrown: '#C6A77D',
  cream: '#F3E7D3',
  softBeige: '#E9DCC4',
  white: '#FFFFFF',
};

// Week Data - All 7 Weeks with 22 Doctrines
const weeksData = {
  1: {
    number: 1,
    title: 'Foundations',
    subtitle: 'Building on What You Can Trust',
    doctrines: 'A-C',
    time: '60 min',
    memoryVerse: {
      text: '"All Scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness."',
      reference: '2 Timothy 3:16'
    },
    sections: [
      { 
        id: 'A', 
        letter: 'A',
        emoji: '📖', 
        title: 'The Scriptures', 
        subtitle: "God's Inspired Word", 
        time: '15 min',
        keyTruth: 'The Bible is God-breathed, written by men moved by the Holy Spirit. It is our ultimate authority for faith and life.',
        keyVerses: [
          { ref: '2 Peter 1:21', text: 'Holy men of God spoke as they were moved by the Holy Spirit' },
          { ref: '2 Timothy 3:16-17', text: 'All Scripture is given by inspiration of God (God-breathed)' },
          { ref: '1 Corinthians 2:13', text: 'Words not from man\'s wisdom but from the Spirit' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'B', 
        letter: 'B',
        emoji: '✨', 
        title: 'The Trinity', 
        subtitle: 'One God, Three Persons', 
        time: '20 min',
        keyTruth: 'God exists eternally as Father, Son, and Holy Spirit—three distinct persons, yet one God.',
        keyVerses: [
          { ref: 'Genesis 1:1', text: 'In the beginning God [Elohim - plural]' },
          { ref: 'Genesis 1:26', text: '"Let Us make man in Our image..."' },
          { ref: 'Matthew 28:19', text: 'Baptize in the name of Father, Son, Holy Spirit' },
          { ref: '1 John 5:7', text: 'These three are one' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'C', 
        letter: 'C',
        emoji: '👼', 
        title: 'Angels & Demons', 
        subtitle: 'The Spiritual Realm', 
        time: '15 min',
        keyTruth: 'God created angels as spiritual beings. Some fell with Satan, others remained faithful and serve God.',
        keyVerses: [
          { ref: 'Ezekiel 28:11-19', text: 'Satan\'s original beauty and perfection' },
          { ref: 'Isaiah 14:12-15', text: 'His fall through pride - five "I wills"' },
          { ref: 'Hebrews 1:14', text: 'Angels are ministering spirits for believers' },
        ],
        color: colors.lightBrown
      },
    ]
  },
  2: {
    number: 2,
    title: 'Humanity & Salvation',
    subtitle: 'Understanding Our Need and God\'s Answer',
    doctrines: 'D-F',
    time: '60 min',
    memoryVerse: {
      text: '"For all have sinned, and come short of the glory of God; Being justified freely by his grace through the redemption that is in Christ Jesus."',
      reference: 'Romans 3:23-24'
    },
    sections: [
      { 
        id: 'D', 
        letter: 'D',
        emoji: '🧑', 
        title: 'Man', 
        subtitle: 'Created in God\'s Image', 
        time: '15 min',
        keyTruth: 'Man was created in God\'s image, fell through Adam\'s sin, and now all humanity inherits a sinful nature.',
        keyVerses: [
          { ref: 'Genesis 1:27', text: 'God created man in His own image' },
          { ref: 'Romans 5:12', text: 'Through one man sin entered the world' },
          { ref: 'Psalm 51:5', text: 'Behold, I was shapen in iniquity' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'E', 
        letter: 'E',
        emoji: '💔', 
        title: 'Sin', 
        subtitle: 'The Human Condition', 
        time: '20 min',
        keyTruth: 'Sin is transgression of God\'s law. All have sinned, and the wages of sin is death—both physical and spiritual.',
        keyVerses: [
          { ref: '1 John 3:4', text: 'Sin is the transgression of the law' },
          { ref: 'Romans 3:23', text: 'All have sinned and come short of the glory of God' },
          { ref: 'Romans 6:23', text: 'The wages of sin is death' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'F', 
        letter: 'F',
        emoji: '✝️', 
        title: 'Salvation', 
        subtitle: 'Grace Through Faith', 
        time: '25 min',
        keyTruth: 'Salvation is by grace alone through faith alone in Christ alone. It is a gift, not earned by works.',
        keyVerses: [
          { ref: 'Ephesians 2:8-9', text: 'By grace you are saved through faith, not of works' },
          { ref: 'John 3:16', text: 'God so loved the world that He gave His only Son' },
          { ref: 'Romans 10:9-10', text: 'Confess and believe for salvation' },
        ],
        color: colors.lightBrown
      },
    ]
  },
  3: {
    number: 3,
    title: 'The Church',
    subtitle: 'God\'s People United',
    doctrines: 'G-I',
    time: '55 min',
    memoryVerse: {
      text: '"For by one Spirit are we all baptized into one body, whether we be Jews or Gentiles, whether we be bond or free."',
      reference: '1 Corinthians 12:13'
    },
    sections: [
      { 
        id: 'G', 
        letter: 'G',
        emoji: '🎁', 
        title: 'Grace', 
        subtitle: 'Unmerited Favor', 
        time: '15 min',
        keyTruth: 'Grace is God\'s unmerited favor—receiving what we don\'t deserve. It is the foundation of our salvation.',
        keyVerses: [
          { ref: 'Ephesians 2:8', text: 'By grace you are saved through faith' },
          { ref: 'Titus 2:11', text: 'The grace of God brings salvation to all' },
          { ref: 'Romans 5:20', text: 'Where sin abounded, grace did much more abound' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'H', 
        letter: 'H',
        emoji: '⛪', 
        title: 'The Church', 
        subtitle: 'Body of Christ', 
        time: '20 min',
        keyTruth: 'The Church is the Body of Christ, composed of all born-again believers, both universal and local.',
        keyVerses: [
          { ref: 'Ephesians 1:22-23', text: 'The church is His body, the fullness of Him' },
          { ref: 'Matthew 16:18', text: 'Upon this rock I will build my church' },
          { ref: '1 Corinthians 12:27', text: 'You are the body of Christ' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'I', 
        letter: 'I',
        emoji: '💧', 
        title: 'Ordinances', 
        subtitle: 'Baptism & Communion', 
        time: '20 min',
        keyTruth: 'The two ordinances of the Church are water baptism by immersion and the Lord\'s Supper—both are symbols, not sacraments.',
        keyVerses: [
          { ref: 'Matthew 28:19', text: 'Go and make disciples, baptizing them' },
          { ref: 'Acts 2:41', text: 'They that received his word were baptized' },
          { ref: '1 Corinthians 11:24-25', text: 'This do in remembrance of me' },
        ],
        color: colors.lightBrown
      },
    ]
  },
  4: {
    number: 4,
    title: 'Christian Life',
    subtitle: 'Growing in Christ',
    doctrines: 'J-L',
    time: '55 min',
    memoryVerse: {
      text: '"Being confident of this very thing, that he which hath begun a good work in you will perform it until the day of Jesus Christ."',
      reference: 'Philippians 1:6'
    },
    sections: [
      { 
        id: 'J', 
        letter: 'J',
        emoji: '🌱', 
        title: 'Sanctification', 
        subtitle: 'Set Apart for God', 
        time: '20 min',
        keyTruth: 'Sanctification is the process of being set apart and made holy. It begins at salvation and continues throughout life.',
        keyVerses: [
          { ref: '1 Thessalonians 4:3', text: 'This is the will of God, your sanctification' },
          { ref: '2 Corinthians 7:1', text: 'Perfecting holiness in the fear of God' },
          { ref: 'Hebrews 12:14', text: 'Follow holiness, without which no man shall see the Lord' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'K', 
        letter: 'K',
        emoji: '🔒', 
        title: 'Security', 
        subtitle: 'Eternally Kept', 
        time: '20 min',
        keyTruth: 'The believer is eternally secure in Christ. Once saved, we are kept by the power of God, not our own efforts.',
        keyVerses: [
          { ref: 'John 10:28-29', text: 'No one can snatch them out of my hand' },
          { ref: 'Romans 8:38-39', text: 'Nothing can separate us from the love of God' },
          { ref: '1 Peter 1:5', text: 'Kept by the power of God through faith' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'L', 
        letter: 'L',
        emoji: '🤝', 
        title: 'Service', 
        subtitle: 'Called to Serve', 
        time: '15 min',
        keyTruth: 'Every believer is called to serve God and others using their spiritual gifts for the building up of the body.',
        keyVerses: [
          { ref: 'Ephesians 2:10', text: 'Created in Christ Jesus for good works' },
          { ref: '1 Peter 4:10', text: 'Minister your gift to one another' },
          { ref: 'Galatians 5:13', text: 'By love serve one another' },
        ],
        color: colors.lightBrown
      },
    ]
  },
  5: {
    number: 5,
    title: 'Spiritual Gifts',
    subtitle: 'Empowered for Ministry',
    doctrines: 'M-O',
    time: '55 min',
    memoryVerse: {
      text: '"Now there are diversities of gifts, but the same Spirit. And there are differences of administrations, but the same Lord."',
      reference: '1 Corinthians 12:4-5'
    },
    sections: [
      { 
        id: 'M', 
        letter: 'M',
        emoji: '🎯', 
        title: 'Spiritual Gifts', 
        subtitle: 'Given by the Spirit', 
        time: '20 min',
        keyTruth: 'Spiritual gifts are given by the Holy Spirit to every believer for the edification of the church.',
        keyVerses: [
          { ref: '1 Corinthians 12:7', text: 'The manifestation of the Spirit is given to every man' },
          { ref: 'Romans 12:6-8', text: 'Gifts differing according to grace' },
          { ref: '1 Peter 4:10', text: 'As good stewards of the manifold grace of God' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'N', 
        letter: 'N',
        emoji: '💪', 
        title: 'Divine Healing', 
        subtitle: 'Provided in Atonement', 
        time: '20 min',
        keyTruth: 'Divine healing is provided in the atonement and is available to believers today through prayer and faith.',
        keyVerses: [
          { ref: 'Isaiah 53:5', text: 'By His stripes we are healed' },
          { ref: 'James 5:14-15', text: 'The prayer of faith shall save the sick' },
          { ref: 'Matthew 8:17', text: 'Himself took our infirmities' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'O', 
        letter: 'O',
        emoji: '🍞', 
        title: "Lord's Supper", 
        subtitle: 'Remembrance & Proclamation', 
        time: '15 min',
        keyTruth: 'The Lord\'s Supper is a memorial of Christ\'s death, a proclamation of His return, and a time of self-examination.',
        keyVerses: [
          { ref: '1 Corinthians 11:24-26', text: 'This do in remembrance of me' },
          { ref: 'Luke 22:19-20', text: 'This cup is the new testament in my blood' },
          { ref: '1 Corinthians 11:28', text: 'Let a man examine himself' },
        ],
        color: colors.lightBrown
      },
    ]
  },
  6: {
    number: 6,
    title: 'End Times',
    subtitle: 'The Blessed Hope',
    doctrines: 'P-R',
    time: '60 min',
    memoryVerse: {
      text: '"For the Lord himself shall descend from heaven with a shout, with the voice of the archangel, and with the trump of God: and the dead in Christ shall rise first."',
      reference: '1 Thessalonians 4:16'
    },
    sections: [
      { 
        id: 'P', 
        letter: 'P',
        emoji: '☁️', 
        title: 'Second Coming', 
        subtitle: 'The Blessed Hope', 
        time: '25 min',
        keyTruth: 'Jesus Christ will return bodily, visibly, and personally. The rapture of the church precedes the tribulation.',
        keyVerses: [
          { ref: 'Acts 1:11', text: 'This same Jesus shall so come in like manner' },
          { ref: '1 Thessalonians 4:16-17', text: 'Caught up together to meet the Lord' },
          { ref: 'Titus 2:13', text: 'Looking for that blessed hope' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'Q', 
        letter: 'Q',
        emoji: '⬆️', 
        title: 'Resurrection', 
        subtitle: 'Victory Over Death', 
        time: '20 min',
        keyTruth: 'All will be resurrected—believers to eternal life in glorified bodies, unbelievers to eternal judgment.',
        keyVerses: [
          { ref: '1 Corinthians 15:51-52', text: 'We shall all be changed' },
          { ref: 'John 5:28-29', text: 'All in the graves shall hear his voice' },
          { ref: 'Philippians 3:21', text: 'He shall change our vile body' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'R', 
        letter: 'R',
        emoji: '⚖️', 
        title: 'Final Judgment', 
        subtitle: 'Before the Throne', 
        time: '15 min',
        keyTruth: 'Believers face the Judgment Seat of Christ for rewards; unbelievers face the Great White Throne for condemnation.',
        keyVerses: [
          { ref: '2 Corinthians 5:10', text: 'We must all appear before the judgment seat' },
          { ref: 'Revelation 20:11-15', text: 'The Great White Throne judgment' },
          { ref: 'Romans 14:12', text: 'Every one shall give account of himself' },
        ],
        color: colors.lightBrown
      },
    ]
  },
  7: {
    number: 7,
    title: 'Eternity & Mission',
    subtitle: 'Forever with the Lord',
    doctrines: 'S-V',
    time: '70 min',
    memoryVerse: {
      text: '"Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost."',
      reference: 'Matthew 28:19'
    },
    sections: [
      { 
        id: 'S', 
        letter: 'S',
        emoji: '🏛️', 
        title: 'Heaven', 
        subtitle: 'Eternal Dwelling', 
        time: '15 min',
        keyTruth: 'Heaven is a real place where believers will dwell eternally with God in His presence, free from sin and sorrow.',
        keyVerses: [
          { ref: 'John 14:2-3', text: 'In my Father\'s house are many mansions' },
          { ref: 'Revelation 21:4', text: 'No more death, sorrow, crying, or pain' },
          { ref: '2 Corinthians 5:8', text: 'Absent from the body, present with the Lord' },
        ],
        color: colors.darkBrown
      },
      { 
        id: 'T', 
        letter: 'T',
        emoji: '🔥', 
        title: 'Hell', 
        subtitle: 'Eternal Separation', 
        time: '15 min',
        keyTruth: 'Hell is a real place of eternal conscious punishment for those who reject Christ—separation from God forever.',
        keyVerses: [
          { ref: 'Matthew 25:46', text: 'Everlasting punishment vs. life eternal' },
          { ref: 'Revelation 20:15', text: 'Cast into the lake of fire' },
          { ref: 'Mark 9:43-44', text: 'The fire that never shall be quenched' },
        ],
        color: colors.mediumBrown
      },
      { 
        id: 'U', 
        letter: 'U',
        emoji: '📢', 
        title: 'Evangelism', 
        subtitle: 'Sharing the Gospel', 
        time: '20 min',
        keyTruth: 'Every believer is called to be an ambassador for Christ, sharing the gospel with the lost world.',
        keyVerses: [
          { ref: 'Matthew 28:19-20', text: 'Go and make disciples of all nations' },
          { ref: '2 Corinthians 5:20', text: 'We are ambassadors for Christ' },
          { ref: 'Romans 10:14', text: 'How shall they hear without a preacher?' },
        ],
        color: colors.lightBrown
      },
      { 
        id: 'V', 
        letter: 'V',
        emoji: '💰', 
        title: 'Stewardship', 
        subtitle: 'Faithful Management', 
        time: '20 min',
        keyTruth: 'Everything we have belongs to God. We are stewards called to faithfully manage our time, talents, and treasures.',
        keyVerses: [
          { ref: 'Malachi 3:10', text: 'Bring ye all the tithes into the storehouse' },
          { ref: '1 Corinthians 4:2', text: 'It is required that stewards be found faithful' },
          { ref: 'Luke 16:10', text: 'He that is faithful in least is faithful in much' },
        ],
        color: colors.darkBrown
      },
    ]
  }
};

export default function ChurchDoctrinalApp() {
  const [currentScreen, setCurrentScreen] = useState('home'); // 'home', 'weeks', 'week', 'doctrine', 'profile'
  const [currentWeek, setCurrentWeek] = useState(1);
  const [currentDoctrine, setCurrentDoctrine] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [completedSections, setCompletedSections] = useState(['A']);
  const [bookmarked, setBookmarked] = useState([]);

  const weekData = weeksData[currentWeek];

  const toggleComplete = (id) => {
    if (completedSections.includes(id)) {
      setCompletedSections(completedSections.filter(s => s !== id));
    } else {
      setCompletedSections([...completedSections, id]);
    }
  };

  const toggleBookmark = () => {
    const key = `week${currentWeek}`;
    if (bookmarked.includes(key)) {
      setBookmarked(bookmarked.filter(b => b !== key));
    } else {
      setBookmarked([...bookmarked, key]);
    }
  };

  const navigateToWeek = (weekNum) => {
    setCurrentWeek(weekNum);
    setCurrentScreen('week');
    setActiveTab('overview');
  };

  const navigateToDoctrine = (doctrine) => {
    setCurrentDoctrine(doctrine);
    setCurrentScreen('doctrine');
  };

  const goBack = () => {
    if (currentScreen === 'doctrine') {
      setCurrentScreen('week');
      setCurrentDoctrine(null);
    } else if (currentScreen === 'week') {
      setCurrentScreen('weeks');
    } else {
      setCurrentScreen('home');
    }
  };

  // Calculate progress
  const totalDoctrines = 22;
  const completedCount = completedSections.length;
  const progressPercent = Math.round((completedCount / totalDoctrines) * 100);

  return (
    <div className="flex justify-center items-center min-h-screen p-4" style={{ background: `linear-gradient(135deg, ${colors.cream} 0%, ${colors.softBeige} 100%)` }}>
      {/* iPhone Frame */}
      <div className="relative w-full max-w-sm">
        {/* Phone Notch */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-40 h-7 bg-black rounded-b-3xl z-20"></div>
        
        {/* Phone Screen */}
        <div className="rounded-[3rem] shadow-2xl overflow-hidden border-8 border-black" style={{ background: colors.cream }}>
          {/* Status Bar */}
          <div className="px-6 pt-12 pb-3 flex justify-between items-center text-xs" style={{ background: colors.darkBrown, color: colors.cream }}>
            <span className="font-semibold">9:41</span>
            <div className="flex gap-1">
              <div className="w-4 h-3 border rounded-sm" style={{ borderColor: colors.cream }}></div>
              <div className="w-4 h-3 border rounded-sm" style={{ borderColor: colors.cream }}></div>
              <div className="w-4 h-3 rounded-sm" style={{ background: colors.cream }}></div>
            </div>
          </div>

          {/* HOME SCREEN */}
          {currentScreen === 'home' && (
            <>
              {/* Hero Header */}
              <div className="relative px-6 pb-8 overflow-hidden" style={{ background: `linear-gradient(135deg, ${colors.darkBrown} 0%, ${colors.mediumBrown} 100%)` }}>
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl" style={{ background: colors.lightBrown, opacity: 0.2 }}></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full blur-xl" style={{ background: colors.cream, opacity: 0.1 }}></div>
                
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {/* Logo placeholder */}
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: colors.lightBrown }}>
                        <span className="text-xl">⛪</span>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <Bell className="w-5 h-5" style={{ color: colors.cream }} />
                      <Settings className="w-5 h-5" style={{ color: colors.cream }} />
                    </div>
                  </div>
                  
                  <h1 className="text-2xl font-bold mb-1" style={{ color: colors.cream }}>
                    Church Doctrinal
                  </h1>
                  <p className="text-lg font-semibold mb-1" style={{ color: colors.lightBrown }}>
                    Statement of Faith
                  </p>
                  <p className="text-sm" style={{ color: colors.cream, opacity: 0.9 }}>
                    7 Weeks • 22 Doctrines • 1 Foundation
                  </p>
                </div>
              </div>

              {/* Content */}
              <div className="rounded-t-3xl -mt-4 relative z-10 p-6 h-[480px] overflow-y-auto" style={{ background: colors.cream }}>
                
                {/* Progress Card */}
                <div className="rounded-2xl p-5 mb-6 shadow-lg" style={{ background: colors.white }}>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-lg" style={{ color: colors.darkBrown }}>Your Progress</h3>
                    <span className="text-sm font-semibold" style={{ color: colors.mediumBrown }}>{completedCount}/22 doctrines</span>
                  </div>
                  <div className="w-full rounded-full h-3 mb-3 overflow-hidden" style={{ background: colors.softBeige }}>
                    <div 
                      className="h-3 rounded-full transition-all duration-500"
                      style={{ width: `${progressPercent}%`, background: `linear-gradient(90deg, ${colors.darkBrown}, ${colors.lightBrown})` }}
                    ></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4" style={{ color: colors.lightBrown }} />
                    <span className="text-xs" style={{ color: colors.mediumBrown }}>
                      {progressPercent < 100 ? `${100 - progressPercent}% to go! Keep learning!` : '🎉 Course Complete!'}
                    </span>
                  </div>
                </div>

                {/* Continue Learning */}
                <div className="mb-6">
                  <h3 className="font-bold mb-3" style={{ color: colors.darkBrown }}>Continue Learning</h3>
                  <div 
                    className="rounded-2xl p-4 cursor-pointer shadow-md transition-transform hover:scale-[1.02]"
                    style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` }}
                    onClick={() => navigateToWeek(currentWeek)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl font-bold" style={{ background: colors.lightBrown, color: colors.darkBrown }}>
                          {currentWeek}
                        </div>
                        <div>
                          <p className="font-bold" style={{ color: colors.cream }}>{weekData.title}</p>
                          <p className="text-sm" style={{ color: colors.lightBrown }}>Doctrines {weekData.doctrines}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <Clock className="w-3 h-3" style={{ color: colors.cream, opacity: 0.8 }} />
                            <span className="text-xs" style={{ color: colors.cream, opacity: 0.8 }}>{weekData.time}</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-6 h-6" style={{ color: colors.lightBrown }} />
                    </div>
                  </div>
                </div>

                {/* Quick Access */}
                <div className="mb-6">
                  <h3 className="font-bold mb-3" style={{ color: colors.darkBrown }}>Quick Access</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div 
                      className="rounded-xl p-4 cursor-pointer transition-transform hover:scale-[1.02]"
                      style={{ background: colors.white, boxShadow: '0 2px 10px rgba(74,58,40,0.1)' }}
                      onClick={() => setCurrentScreen('weeks')}
                    >
                      <BookOpen className="w-6 h-6 mb-2" style={{ color: colors.mediumBrown }} />
                      <p className="font-semibold text-sm" style={{ color: colors.darkBrown }}>All Weeks</p>
                      <p className="text-xs" style={{ color: colors.mediumBrown }}>Browse lessons</p>
                    </div>
                    <div 
                      className="rounded-xl p-4 cursor-pointer transition-transform hover:scale-[1.02]"
                      style={{ background: colors.white, boxShadow: '0 2px 10px rgba(74,58,40,0.1)' }}
                    >
                      <Download className="w-6 h-6 mb-2" style={{ color: colors.mediumBrown }} />
                      <p className="font-semibold text-sm" style={{ color: colors.darkBrown }}>Workbooks</p>
                      <p className="text-xs" style={{ color: colors.mediumBrown }}>PDF downloads</p>
                    </div>
                  </div>
                </div>

                {/* Memory Verse of the Day */}
                <div className="rounded-2xl p-5 shadow-md" style={{ background: `linear-gradient(135deg, ${colors.lightBrown}, ${colors.mediumBrown})` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-4 h-4" style={{ color: colors.cream }} />
                    <span className="text-xs font-bold uppercase tracking-wide" style={{ color: colors.cream }}>Memory Verse</span>
                  </div>
                  <p className="text-sm italic leading-relaxed mb-2" style={{ color: colors.cream }}>
                    {weekData.memoryVerse.text}
                  </p>
                  <p className="text-xs font-semibold" style={{ color: colors.darkBrown }}>— {weekData.memoryVerse.reference}</p>
                </div>
              </div>
            </>
          )}

          {/* WEEKS LIST SCREEN */}
          {currentScreen === 'weeks' && (
            <>
              <div className="px-6 pb-6" style={{ background: colors.darkBrown }}>
                <div className="flex items-center gap-3 mb-4">
                  <ChevronLeft className="w-6 h-6 cursor-pointer" style={{ color: colors.cream }} onClick={goBack} />
                  <h1 className="text-xl font-bold" style={{ color: colors.cream }}>All Weeks</h1>
                </div>
                <p className="text-sm" style={{ color: colors.lightBrown }}>7 weeks of foundational doctrine study</p>
              </div>

              <div className="rounded-t-3xl -mt-4 relative z-10 p-6 h-[520px] overflow-y-auto" style={{ background: colors.cream }}>
                <div className="space-y-3">
                  {Object.values(weeksData).map((week) => (
                    <div 
                      key={week.number}
                      className="rounded-xl p-4 cursor-pointer transition-all hover:shadow-md"
                      style={{ background: colors.white, border: `1px solid ${colors.softBeige}` }}
                      onClick={() => navigateToWeek(week.number)}
                    >
                      <div className="flex items-center gap-4">
                        <div 
                          className="w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold flex-shrink-0"
                          style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`, color: colors.cream }}
                        >
                          {week.number}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold" style={{ color: colors.darkBrown }}>{week.title}</h3>
                          <p className="text-sm" style={{ color: colors.mediumBrown }}>Doctrines {week.doctrines}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock className="w-3 h-3" style={{ color: colors.lightBrown }} />
                            <span className="text-xs" style={{ color: colors.mediumBrown }}>{week.time}</span>
                            <span className="text-xs" style={{ color: colors.mediumBrown }}>•</span>
                            <span className="text-xs" style={{ color: colors.mediumBrown }}>{week.sections.length} doctrines</span>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5" style={{ color: colors.lightBrown }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* WEEK DETAIL SCREEN */}
          {currentScreen === 'week' && (
            <>
              {/* Hero Header */}
              <div className="relative px-6 pb-8 overflow-hidden" style={{ background: `linear-gradient(135deg, ${colors.darkBrown} 0%, ${colors.mediumBrown} 100%)` }}>
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl" style={{ background: colors.lightBrown, opacity: 0.15 }}></div>
                
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-6">
                    <ChevronLeft className="w-6 h-6 cursor-pointer" style={{ color: colors.cream }} onClick={goBack} />
                    <div className="flex gap-3">
                      <Bookmark 
                        className="w-5 h-5 cursor-pointer" 
                        style={{ color: colors.cream, fill: bookmarked.includes(`week${currentWeek}`) ? colors.cream : 'transparent' }} 
                        onClick={toggleBookmark}
                      />
                      <Share2 className="w-5 h-5" style={{ color: colors.cream }} />
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 mb-3">
                    <span className="px-3 py-1 rounded-full text-xs font-medium" style={{ background: 'rgba(255,255,255,0.2)', color: colors.cream }}>
                      Week {currentWeek}
                    </span>
                    <span className="text-xs" style={{ color: colors.cream, opacity: 0.8 }}>•</span>
                    <span className="text-xs" style={{ color: colors.cream, opacity: 0.8 }}>{weekData.time}</span>
                    <span className="text-xs" style={{ color: colors.cream, opacity: 0.8 }}>•</span>
                    <span className="px-2 py-1 rounded-full text-xs font-bold" style={{ background: colors.lightBrown, color: colors.darkBrown }}>
                      {weekData.doctrines}
                    </span>
                  </div>
                  
                  <h1 className="text-3xl font-bold mb-2 leading-tight" style={{ color: colors.cream }}>
                    {weekData.title}
                  </h1>
                  <p className="text-sm" style={{ color: colors.lightBrown }}>
                    {weekData.subtitle}
                  </p>
                </div>
              </div>

              {/* Content */}
              <div className="rounded-t-3xl -mt-4 relative z-10" style={{ background: colors.cream }}>
                <div className="p-6 h-[440px] overflow-y-auto">
                  
                  {/* Tab Navigation */}
                  <div className="flex gap-2 mb-6 p-1 rounded-2xl" style={{ background: colors.softBeige }}>
                    <button 
                      onClick={() => setActiveTab('overview')}
                      className="flex-1 py-2 px-4 rounded-xl text-sm font-bold transition-all"
                      style={{ 
                        background: activeTab === 'overview' ? colors.white : 'transparent',
                        color: activeTab === 'overview' ? colors.darkBrown : colors.mediumBrown,
                        boxShadow: activeTab === 'overview' ? '0 2px 8px rgba(74,58,40,0.1)' : 'none'
                      }}
                    >
                      Overview
                    </button>
                    <button 
                      onClick={() => setActiveTab('content')}
                      className="flex-1 py-2 px-4 rounded-xl text-sm font-bold transition-all"
                      style={{ 
                        background: activeTab === 'content' ? colors.white : 'transparent',
                        color: activeTab === 'content' ? colors.darkBrown : colors.mediumBrown,
                        boxShadow: activeTab === 'content' ? '0 2px 8px rgba(74,58,40,0.1)' : 'none'
                      }}
                    >
                      Content
                    </button>
                  </div>

                  {activeTab === 'overview' && (
                    <>
                      {/* Memory Verse */}
                      <div className="rounded-2xl p-5 mb-6 overflow-hidden shadow-lg" style={{ background: `linear-gradient(135deg, ${colors.lightBrown}, ${colors.mediumBrown})` }}>
                        <div className="relative z-10">
                          <div className="flex items-center gap-2 mb-3">
                            <Zap className="w-4 h-4" style={{ color: colors.cream }} />
                            <span className="text-xs font-bold uppercase tracking-wide" style={{ color: colors.cream }}>This Week's Verse</span>
                          </div>
                          <p className="text-sm font-medium leading-relaxed mb-2" style={{ color: colors.cream }}>
                            {weekData.memoryVerse.text}
                          </p>
                          <p className="text-xs mb-4" style={{ color: colors.darkBrown }}>— {weekData.memoryVerse.reference}</p>
                          <button className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium" style={{ background: 'rgba(255,255,255,0.25)', color: colors.cream }}>
                            <Volume2 className="w-3 h-3" />
                            Listen to verse
                          </button>
                        </div>
                      </div>

                      {/* Doctrine Cards */}
                      <h3 className="font-bold mb-3" style={{ color: colors.darkBrown }}>This Week's Doctrines</h3>
                      <div className="space-y-3 mb-6">
                        {weekData.sections.map((section) => (
                          <div 
                            key={section.id}
                            className="rounded-2xl p-4 transition-all cursor-pointer"
                            style={{ 
                              background: completedSections.includes(section.id) ? colors.softBeige : colors.white,
                              border: `2px solid ${completedSections.includes(section.id) ? colors.lightBrown : colors.softBeige}`
                            }}
                            onClick={() => navigateToDoctrine(section)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3 flex-1">
                                <div 
                                  className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold"
                                  style={{ 
                                    background: completedSections.includes(section.id) 
                                      ? `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`
                                      : colors.softBeige,
                                    color: completedSections.includes(section.id) ? colors.cream : colors.darkBrown
                                  }}
                                >
                                  {completedSections.includes(section.id) ? '✓' : section.emoji}
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background: colors.softBeige, color: colors.darkBrown }}>
                                      {section.letter}
                                    </span>
                                    <h4 className="font-semibold text-sm" style={{ color: colors.darkBrown }}>{section.title}</h4>
                                  </div>
                                  <p className="text-xs" style={{ color: colors.mediumBrown }}>{section.subtitle}</p>
                                  <div className="flex items-center gap-1 mt-1">
                                    <Clock className="w-3 h-3" style={{ color: colors.lightBrown }} />
                                    <span className="text-xs" style={{ color: colors.mediumBrown }}>{section.time}</span>
                                  </div>
                                </div>
                              </div>
                              <ChevronRight className="w-5 h-5" style={{ color: colors.lightBrown }} />
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Action Buttons */}
                      <div className="space-y-3">
                        <button 
                          className="w-full py-4 rounded-2xl font-bold text-base shadow-lg transition-transform hover:scale-[1.02]"
                          style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`, color: colors.cream }}
                          onClick={() => navigateToDoctrine(weekData.sections[0])}
                        >
                          Start Week {currentWeek} →
                        </button>
                        <button 
                          className="w-full py-4 rounded-2xl font-semibold text-base"
                          style={{ background: colors.softBeige, color: colors.darkBrown }}
                        >
                          Download Workbook
                        </button>
                      </div>
                    </>
                  )}

                  {activeTab === 'content' && (
                    <>
                      {weekData.sections.map((section) => (
                        <div key={section.id} className="mb-6">
                          <div className="flex items-center gap-3 mb-4">
                            <div 
                              className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold"
                              style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`, color: colors.cream }}
                            >
                              {section.letter}
                            </div>
                            <div>
                              <h3 className="text-lg font-bold" style={{ color: colors.darkBrown }}>{section.title}</h3>
                              <p className="text-sm" style={{ color: colors.mediumBrown }}>{section.subtitle}</p>
                            </div>
                          </div>
                          
                          <div className="rounded-lg p-4 mb-4" style={{ background: colors.softBeige, borderLeft: `4px solid ${colors.lightBrown}` }}>
                            <p className="text-sm leading-relaxed" style={{ color: colors.darkBrown }}>
                              <strong style={{ color: colors.darkBrown }}>Key Truth:</strong> {section.keyTruth}
                            </p>
                          </div>

                          <div className="rounded-xl p-4" style={{ background: colors.white, border: `1px solid ${colors.softBeige}` }}>
                            <p className="text-xs font-bold uppercase mb-2" style={{ color: colors.mediumBrown }}>Key Verses</p>
                            {section.keyVerses.map((verse, i) => (
                              <p key={i} className="text-sm mb-2" style={{ color: colors.darkBrown }}>
                                <strong>{verse.ref}</strong> - {verse.text}
                              </p>
                            ))}
                          </div>

                          <button 
                            className="mt-3 text-sm font-semibold flex items-center gap-1"
                            style={{ color: colors.mediumBrown }}
                            onClick={() => toggleComplete(section.id)}
                          >
                            {completedSections.includes(section.id) ? (
                              <>
                                <CheckCircle className="w-4 h-4" style={{ color: colors.darkBrown }} />
                                <span>Completed</span>
                              </>
                            ) : (
                              <>
                                <div className="w-4 h-4 rounded-full border-2" style={{ borderColor: colors.lightBrown }}></div>
                                <span>Mark as complete</span>
                              </>
                            )}
                          </button>
                        </div>
                      ))}
                    </>
                  )}
                </div>

                {/* Week Navigation */}
                <div className="flex justify-between items-center px-6 py-4 border-t" style={{ borderColor: colors.softBeige }}>
                  {currentWeek > 1 ? (
                    <button 
                      className="flex items-center gap-1 text-sm font-medium"
                      style={{ color: colors.mediumBrown }}
                      onClick={() => navigateToWeek(currentWeek - 1)}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Week {currentWeek - 1}
                    </button>
                  ) : <div></div>}
                  
                  {currentWeek < 7 ? (
                    <button 
                      className="flex items-center gap-1 text-sm font-medium"
                      style={{ color: colors.mediumBrown }}
                      onClick={() => navigateToWeek(currentWeek + 1)}
                    >
                      Week {currentWeek + 1}
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : <div></div>}
                </div>
              </div>
            </>
          )}

          {/* DOCTRINE DETAIL SCREEN */}
          {currentScreen === 'doctrine' && currentDoctrine && (
            <>
              <div className="px-6 pb-6" style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` }}>
                <div className="flex items-center justify-between mb-4">
                  <ChevronLeft className="w-6 h-6 cursor-pointer" style={{ color: colors.cream }} onClick={goBack} />
                  <div className="flex gap-3">
                    <button 
                      className="p-2 rounded-full"
                      style={{ background: 'rgba(255,255,255,0.15)' }}
                      onClick={() => toggleComplete(currentDoctrine.id)}
                    >
                      <CheckCircle 
                        className="w-5 h-5" 
                        style={{ 
                          color: colors.cream,
                          fill: completedSections.includes(currentDoctrine.id) ? colors.cream : 'transparent'
                        }} 
                      />
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div 
                    className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-2xl"
                    style={{ background: colors.lightBrown, color: colors.darkBrown }}
                  >
                    {currentDoctrine.letter}
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold" style={{ color: colors.cream }}>{currentDoctrine.title}</h1>
                    <p className="text-sm" style={{ color: colors.lightBrown }}>{currentDoctrine.subtitle}</p>
                  </div>
                </div>
              </div>

              <div className="rounded-t-3xl -mt-4 relative z-10 p-6 h-[480px] overflow-y-auto" style={{ background: colors.cream }}>
                
                {/* Key Truth */}
                <div className="rounded-2xl p-5 mb-6" style={{ background: colors.white, border: `2px solid ${colors.softBeige}` }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Star className="w-5 h-5" style={{ color: colors.lightBrown }} />
                    <h3 className="font-bold" style={{ color: colors.darkBrown }}>Key Truth</h3>
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: colors.darkBrown }}>
                    {currentDoctrine.keyTruth}
                  </p>
                </div>

                {/* Key Verses */}
                <div className="mb-6">
                  <h3 className="font-bold mb-3 flex items-center gap-2" style={{ color: colors.darkBrown }}>
                    <Book className="w-5 h-5" style={{ color: colors.lightBrown }} />
                    Key Verses
                  </h3>
                  <div className="space-y-3">
                    {currentDoctrine.keyVerses.map((verse, i) => (
                      <div 
                        key={i} 
                        className="rounded-xl p-4"
                        style={{ background: colors.white, borderLeft: `3px solid ${colors.lightBrown}` }}
                      >
                        <p className="font-bold text-sm mb-1" style={{ color: colors.darkBrown }}>{verse.ref}</p>
                        <p className="text-sm" style={{ color: colors.mediumBrown }}>{verse.text}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Discussion Questions */}
                <div className="mb-6">
                  <h3 className="font-bold mb-3 flex items-center gap-2" style={{ color: colors.darkBrown }}>
                    <Users className="w-5 h-5" style={{ color: colors.lightBrown }} />
                    Discussion Questions
                  </h3>
                  <div className="space-y-3">
                    <div className="rounded-xl p-4" style={{ background: colors.softBeige }}>
                      <p className="text-sm" style={{ color: colors.darkBrown }}>
                        1. How does this doctrine impact your daily walk with God?
                      </p>
                    </div>
                    <div className="rounded-xl p-4" style={{ background: colors.softBeige }}>
                      <p className="text-sm" style={{ color: colors.darkBrown }}>
                        2. What questions do you still have about this teaching?
                      </p>
                    </div>
                    <div className="rounded-xl p-4" style={{ background: colors.softBeige }}>
                      <p className="text-sm" style={{ color: colors.darkBrown }}>
                        3. How would you explain this to a new believer?
                      </p>
                    </div>
                  </div>
                </div>

                {/* Prayer Focus */}
                <div className="rounded-2xl p-5 mb-6" style={{ background: `linear-gradient(135deg, ${colors.lightBrown}, ${colors.mediumBrown})` }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Heart className="w-5 h-5" style={{ color: colors.cream }} />
                    <h3 className="font-bold" style={{ color: colors.cream }}>Prayer Focus</h3>
                  </div>
                  <p className="text-sm" style={{ color: colors.cream }}>
                    Lord, help me to understand and apply this truth to my life. May my faith grow stronger as I study Your Word.
                  </p>
                </div>

                {/* Complete Button */}
                <button 
                  className="w-full py-4 rounded-2xl font-bold text-base shadow-lg"
                  style={{ 
                    background: completedSections.includes(currentDoctrine.id) 
                      ? colors.softBeige 
                      : `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`,
                    color: completedSections.includes(currentDoctrine.id) ? colors.darkBrown : colors.cream
                  }}
                  onClick={() => toggleComplete(currentDoctrine.id)}
                >
                  {completedSections.includes(currentDoctrine.id) ? '✓ Completed' : 'Mark as Complete'}
                </button>
              </div>
            </>
          )}

          {/* Bottom Navigation */}
          <div className="flex justify-around py-4" style={{ background: colors.white, borderTop: `1px solid ${colors.softBeige}` }}>
            <button 
              className="flex flex-col items-center gap-1"
              onClick={() => setCurrentScreen('home')}
            >
              <div 
                className="w-12 h-12 rounded-2xl flex items-center justify-center"
                style={{ 
                  background: currentScreen === 'home' ? `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` : colors.softBeige
                }}
              >
                <Home className="w-5 h-5" style={{ color: currentScreen === 'home' ? colors.cream : colors.mediumBrown }} />
              </div>
              <span className="text-xs font-semibold" style={{ color: currentScreen === 'home' ? colors.darkBrown : colors.mediumBrown }}>Home</span>
            </button>
            <button 
              className="flex flex-col items-center gap-1"
              onClick={() => setCurrentScreen('weeks')}
            >
              <div 
                className="w-12 h-12 rounded-2xl flex items-center justify-center"
                style={{ 
                  background: currentScreen === 'weeks' || currentScreen === 'week' ? `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` : colors.softBeige
                }}
              >
                <BookOpen className="w-5 h-5" style={{ color: currentScreen === 'weeks' || currentScreen === 'week' ? colors.cream : colors.mediumBrown }} />
              </div>
              <span className="text-xs font-semibold" style={{ color: currentScreen === 'weeks' || currentScreen === 'week' ? colors.darkBrown : colors.mediumBrown }}>Weeks</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: colors.softBeige }}>
                <Users className="w-5 h-5" style={{ color: colors.mediumBrown }} />
              </div>
              <span className="text-xs" style={{ color: colors.mediumBrown }}>Community</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: colors.softBeige }}>
                <User className="w-5 h-5" style={{ color: colors.mediumBrown }} />
              </div>
              <span className="text-xs" style={{ color: colors.mediumBrown }}>Profile</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
