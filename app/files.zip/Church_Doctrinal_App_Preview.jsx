import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Home, BookOpen, Users, User, Play, CheckCircle, Share2, Bookmark, Zap, Clock, Book, Award, Settings, Bell, Heart, Star, Download, Volume2 } from 'lucide-react';

const colors = {
  darkBrown: '#4A3A28',
  mediumBrown: '#7B5E3C',
  lightBrown: '#C6A77D',
  cream: '#F3E7D3',
  softBeige: '#E9DCC4',
  white: '#FFFFFF',
};

const weeksData = {
  1: {
    number: 1, title: 'Foundations', subtitle: 'Building on What You Can Trust', doctrines: 'A-C', time: '60 min',
    memoryVerse: { text: '"All Scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness."', reference: '2 Timothy 3:16' },
    sections: [
      { id: 'A', letter: 'A', emoji: '📖', title: 'The Scriptures', subtitle: "God's Inspired Word", time: '15 min', keyTruth: 'The Bible is God-breathed, written by men moved by the Holy Spirit. It is our ultimate authority for faith and life.', keyVerses: [{ ref: '2 Peter 1:21', text: 'Holy men spoke as moved by the Holy Spirit' }, { ref: '2 Timothy 3:16-17', text: 'All Scripture is God-breathed' }] },
      { id: 'B', letter: 'B', emoji: '✨', title: 'The Trinity', subtitle: 'One God, Three Persons', time: '20 min', keyTruth: 'God exists eternally as Father, Son, and Holy Spirit—three distinct persons, yet one God.', keyVerses: [{ ref: 'Genesis 1:26', text: '"Let Us make man in Our image..."' }, { ref: 'Matthew 28:19', text: 'Baptize in the name of Father, Son, Holy Spirit' }] },
      { id: 'C', letter: 'C', emoji: '👼', title: 'Angels & Demons', subtitle: 'The Spiritual Realm', time: '15 min', keyTruth: 'God created angels as spiritual beings. Some fell with Satan, others remained faithful.', keyVerses: [{ ref: 'Isaiah 14:12-15', text: 'Satan\'s fall through pride' }, { ref: 'Hebrews 1:14', text: 'Angels are ministering spirits' }] },
    ]
  },
  2: { number: 2, title: 'Humanity & Salvation', subtitle: 'Understanding Our Need', doctrines: 'D-F', time: '60 min', memoryVerse: { text: '"For all have sinned, and come short of the glory of God."', reference: 'Romans 3:23' }, sections: [{ id: 'D', letter: 'D', emoji: '🧑', title: 'Man', subtitle: "Created in God's Image", time: '15 min', keyTruth: 'Man was created in God\'s image but fell through sin.', keyVerses: [] }, { id: 'E', letter: 'E', emoji: '💔', title: 'Sin', subtitle: 'The Human Condition', time: '20 min', keyTruth: 'All have sinned and the wages of sin is death.', keyVerses: [] }, { id: 'F', letter: 'F', emoji: '✝️', title: 'Salvation', subtitle: 'Grace Through Faith', time: '25 min', keyTruth: 'Salvation is by grace through faith alone.', keyVerses: [] }] },
  3: { number: 3, title: 'The Church', subtitle: "God's People United", doctrines: 'G-I', time: '55 min', memoryVerse: { text: '"For by one Spirit are we all baptized into one body."', reference: '1 Cor 12:13' }, sections: [{ id: 'G', letter: 'G', emoji: '🎁', title: 'Grace', subtitle: 'Unmerited Favor', time: '15 min', keyTruth: 'Grace is God\'s unmerited favor.', keyVerses: [] }, { id: 'H', letter: 'H', emoji: '⛪', title: 'The Church', subtitle: 'Body of Christ', time: '20 min', keyTruth: 'The Church is the Body of Christ.', keyVerses: [] }, { id: 'I', letter: 'I', emoji: '💧', title: 'Ordinances', subtitle: 'Baptism & Communion', time: '20 min', keyTruth: 'Two ordinances: baptism and communion.', keyVerses: [] }] },
  4: { number: 4, title: 'Christian Life', subtitle: 'Growing in Christ', doctrines: 'J-L', time: '55 min', memoryVerse: { text: '"He which hath begun a good work in you will perform it."', reference: 'Phil 1:6' }, sections: [{ id: 'J', letter: 'J', emoji: '🌱', title: 'Sanctification', subtitle: 'Set Apart for God', time: '20 min', keyTruth: 'Being set apart and made holy.', keyVerses: [] }, { id: 'K', letter: 'K', emoji: '🔒', title: 'Security', subtitle: 'Eternally Kept', time: '20 min', keyTruth: 'Once saved, kept by God\'s power.', keyVerses: [] }, { id: 'L', letter: 'L', emoji: '🤝', title: 'Service', subtitle: 'Called to Serve', time: '15 min', keyTruth: 'Every believer is called to serve.', keyVerses: [] }] },
  5: { number: 5, title: 'Spiritual Gifts', subtitle: 'Empowered for Ministry', doctrines: 'M-O', time: '55 min', memoryVerse: { text: '"Now there are diversities of gifts, but the same Spirit."', reference: '1 Cor 12:4' }, sections: [{ id: 'M', letter: 'M', emoji: '🎯', title: 'Spiritual Gifts', subtitle: 'Given by the Spirit', time: '20 min', keyTruth: 'Gifts given to every believer.', keyVerses: [] }, { id: 'N', letter: 'N', emoji: '💪', title: 'Divine Healing', subtitle: 'Provided in Atonement', time: '20 min', keyTruth: 'Healing is available through faith.', keyVerses: [] }, { id: 'O', letter: 'O', emoji: '🍞', title: "Lord's Supper", subtitle: 'Remembrance', time: '15 min', keyTruth: 'A memorial of Christ\'s death.', keyVerses: [] }] },
  6: { number: 6, title: 'End Times', subtitle: 'The Blessed Hope', doctrines: 'P-R', time: '60 min', memoryVerse: { text: '"The Lord himself shall descend from heaven with a shout."', reference: '1 Thess 4:16' }, sections: [{ id: 'P', letter: 'P', emoji: '☁️', title: 'Second Coming', subtitle: 'The Blessed Hope', time: '25 min', keyTruth: 'Jesus will return visibly.', keyVerses: [] }, { id: 'Q', letter: 'Q', emoji: '⬆️', title: 'Resurrection', subtitle: 'Victory Over Death', time: '20 min', keyTruth: 'All will be resurrected.', keyVerses: [] }, { id: 'R', letter: 'R', emoji: '⚖️', title: 'Final Judgment', subtitle: 'Before the Throne', time: '15 min', keyTruth: 'All will face judgment.', keyVerses: [] }] },
  7: { number: 7, title: 'Eternity & Mission', subtitle: 'Forever with the Lord', doctrines: 'S-V', time: '70 min', memoryVerse: { text: '"Go ye therefore, and teach all nations."', reference: 'Matt 28:19' }, sections: [{ id: 'S', letter: 'S', emoji: '🏛️', title: 'Heaven', subtitle: 'Eternal Dwelling', time: '15 min', keyTruth: 'Believers dwell eternally with God.', keyVerses: [] }, { id: 'T', letter: 'T', emoji: '🔥', title: 'Hell', subtitle: 'Eternal Separation', time: '15 min', keyTruth: 'Eternal punishment for the lost.', keyVerses: [] }, { id: 'U', letter: 'U', emoji: '📢', title: 'Evangelism', subtitle: 'Sharing the Gospel', time: '20 min', keyTruth: 'Called to share the gospel.', keyVerses: [] }, { id: 'V', letter: 'V', emoji: '💰', title: 'Stewardship', subtitle: 'Faithful Management', time: '20 min', keyTruth: 'Faithful with what God gives.', keyVerses: [] }] },
};

export default function ChurchDoctrinalApp() {
  const [screen, setScreen] = useState('home');
  const [week, setWeek] = useState(1);
  const [tab, setTab] = useState('overview');
  const [completed, setCompleted] = useState(['A']);
  const [bookmarked, setBookmarked] = useState([]);

  const data = weeksData[week];
  const progress = Math.round((completed.length / 22) * 100);

  const navTo = (s, w = week) => { setScreen(s); if (w !== week) setWeek(w); setTab('overview'); };
  const toggle = (id) => setCompleted(completed.includes(id) ? completed.filter(i => i !== id) : [...completed, id]);

  return (
    <div className="flex justify-center items-center min-h-screen p-4" style={{ background: `linear-gradient(135deg, ${colors.cream}, ${colors.softBeige})` }}>
      <div className="relative w-full max-w-sm">
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-40 h-7 bg-black rounded-b-3xl z-20"></div>
        <div className="rounded-[3rem] shadow-2xl overflow-hidden border-8 border-black" style={{ background: colors.cream }}>
          <div className="px-6 pt-12 pb-3 flex justify-between items-center text-xs" style={{ background: colors.darkBrown, color: colors.cream }}>
            <span className="font-semibold">9:41</span>
            <div className="flex gap-1">
              <div className="w-4 h-3 border rounded-sm" style={{ borderColor: colors.cream }}></div>
              <div className="w-4 h-3 rounded-sm" style={{ background: colors.cream }}></div>
            </div>
          </div>

          {screen === 'home' && (
            <>
              <div className="relative px-6 pb-8" style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` }}>
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl" style={{ background: colors.lightBrown, opacity: 0.2 }}></div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-xl" style={{ background: colors.lightBrown }}>⛪</div>
                  <Bell className="w-5 h-5" style={{ color: colors.cream }} />
                </div>
                <h1 className="text-2xl font-bold" style={{ color: colors.cream }}>Church Doctrinal</h1>
                <p className="text-lg font-semibold" style={{ color: colors.lightBrown }}>Statement of Faith</p>
                <p className="text-sm mt-1" style={{ color: colors.cream, opacity: 0.9 }}>7 Weeks • 22 Doctrines • 1 Foundation</p>
              </div>
              <div className="rounded-t-3xl -mt-4 relative z-10 p-6 h-[480px] overflow-y-auto" style={{ background: colors.cream }}>
                <div className="rounded-2xl p-5 mb-6 shadow-lg" style={{ background: colors.white }}>
                  <div className="flex justify-between mb-2">
                    <span className="font-bold" style={{ color: colors.darkBrown }}>Progress</span>
                    <span className="text-sm font-semibold" style={{ color: colors.mediumBrown }}>{completed.length}/22</span>
                  </div>
                  <div className="w-full rounded-full h-3 mb-2" style={{ background: colors.softBeige }}>
                    <div className="h-3 rounded-full transition-all" style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${colors.darkBrown}, ${colors.lightBrown})` }}></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4" style={{ color: colors.lightBrown }} />
                    <span className="text-xs" style={{ color: colors.mediumBrown }}>{progress}% complete</span>
                  </div>
                </div>

                <h3 className="font-bold mb-3" style={{ color: colors.darkBrown }}>Continue Learning</h3>
                <div className="rounded-2xl p-4 mb-6 cursor-pointer shadow-md" style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` }} onClick={() => navTo('week')}>
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl font-bold" style={{ background: colors.lightBrown, color: colors.darkBrown }}>{week}</div>
                    <div className="flex-1">
                      <p className="font-bold" style={{ color: colors.cream }}>{data.title}</p>
                      <p className="text-sm" style={{ color: colors.lightBrown }}>Doctrines {data.doctrines}</p>
                    </div>
                    <ChevronRight className="w-6 h-6" style={{ color: colors.lightBrown }} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="rounded-xl p-4 cursor-pointer" style={{ background: colors.white }} onClick={() => navTo('weeks')}>
                    <BookOpen className="w-6 h-6 mb-2" style={{ color: colors.mediumBrown }} />
                    <p className="font-semibold text-sm" style={{ color: colors.darkBrown }}>All Weeks</p>
                  </div>
                  <div className="rounded-xl p-4" style={{ background: colors.white }}>
                    <Download className="w-6 h-6 mb-2" style={{ color: colors.mediumBrown }} />
                    <p className="font-semibold text-sm" style={{ color: colors.darkBrown }}>Workbooks</p>
                  </div>
                </div>

                <div className="rounded-2xl p-5" style={{ background: `linear-gradient(135deg, ${colors.lightBrown}, ${colors.mediumBrown})` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-4 h-4" style={{ color: colors.cream }} />
                    <span className="text-xs font-bold uppercase" style={{ color: colors.cream }}>Memory Verse</span>
                  </div>
                  <p className="text-sm italic mb-1" style={{ color: colors.cream }}>{data.memoryVerse.text}</p>
                  <p className="text-xs font-semibold" style={{ color: colors.darkBrown }}>— {data.memoryVerse.reference}</p>
                </div>
              </div>
            </>
          )}

          {screen === 'weeks' && (
            <>
              <div className="px-6 pb-6" style={{ background: colors.darkBrown }}>
                <div className="flex items-center gap-3 mb-2">
                  <ChevronLeft className="w-6 h-6 cursor-pointer" style={{ color: colors.cream }} onClick={() => navTo('home')} />
                  <h1 className="text-xl font-bold" style={{ color: colors.cream }}>All Weeks</h1>
                </div>
              </div>
              <div className="rounded-t-3xl -mt-4 p-6 h-[520px] overflow-y-auto" style={{ background: colors.cream }}>
                {Object.values(weeksData).map((w) => (
                  <div key={w.number} className="rounded-xl p-4 mb-3 cursor-pointer" style={{ background: colors.white, border: `1px solid ${colors.softBeige}` }} onClick={() => navTo('week', w.number)}>
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold" style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`, color: colors.cream }}>{w.number}</div>
                      <div className="flex-1">
                        <h3 className="font-bold" style={{ color: colors.darkBrown }}>{w.title}</h3>
                        <p className="text-sm" style={{ color: colors.mediumBrown }}>Doctrines {w.doctrines} • {w.sections.length} lessons</p>
                      </div>
                      <ChevronRight className="w-5 h-5" style={{ color: colors.lightBrown }} />
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {screen === 'week' && (
            <>
              <div className="relative px-6 pb-8" style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` }}>
                <div className="flex items-center justify-between mb-4">
                  <ChevronLeft className="w-6 h-6 cursor-pointer" style={{ color: colors.cream }} onClick={() => navTo('weeks')} />
                  <Bookmark className="w-5 h-5" style={{ color: colors.cream }} />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-3 py-1 rounded-full text-xs" style={{ background: 'rgba(255,255,255,0.2)', color: colors.cream }}>Week {week}</span>
                  <span className="px-2 py-1 rounded-full text-xs font-bold" style={{ background: colors.lightBrown, color: colors.darkBrown }}>{data.doctrines}</span>
                </div>
                <h1 className="text-3xl font-bold" style={{ color: colors.cream }}>{data.title}</h1>
                <p className="text-sm" style={{ color: colors.lightBrown }}>{data.subtitle}</p>
              </div>
              <div className="rounded-t-3xl -mt-4 p-6 h-[420px] overflow-y-auto" style={{ background: colors.cream }}>
                <div className="flex gap-2 mb-6 p-1 rounded-2xl" style={{ background: colors.softBeige }}>
                  {['overview', 'content'].map((t) => (
                    <button key={t} onClick={() => setTab(t)} className="flex-1 py-2 px-4 rounded-xl text-sm font-bold capitalize" style={{ background: tab === t ? colors.white : 'transparent', color: tab === t ? colors.darkBrown : colors.mediumBrown }}>{t}</button>
                  ))}
                </div>

                {tab === 'overview' && (
                  <>
                    <div className="rounded-2xl p-5 mb-6" style={{ background: `linear-gradient(135deg, ${colors.lightBrown}, ${colors.mediumBrown})` }}>
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="w-4 h-4" style={{ color: colors.cream }} />
                        <span className="text-xs font-bold uppercase" style={{ color: colors.cream }}>Memory Verse</span>
                      </div>
                      <p className="text-sm italic" style={{ color: colors.cream }}>{data.memoryVerse.text}</p>
                      <p className="text-xs mt-1" style={{ color: colors.darkBrown }}>— {data.memoryVerse.reference}</p>
                    </div>
                    <h3 className="font-bold mb-3" style={{ color: colors.darkBrown }}>Doctrines</h3>
                    {data.sections.map((s) => (
                      <div key={s.id} className="rounded-2xl p-4 mb-3 cursor-pointer" style={{ background: completed.includes(s.id) ? colors.softBeige : colors.white, border: `2px solid ${completed.includes(s.id) ? colors.lightBrown : colors.softBeige}` }} onClick={() => toggle(s.id)}>
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold" style={{ background: completed.includes(s.id) ? `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` : colors.softBeige, color: completed.includes(s.id) ? colors.cream : colors.darkBrown }}>{completed.includes(s.id) ? '✓' : s.emoji}</div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background: colors.softBeige, color: colors.darkBrown }}>{s.letter}</span>
                              <span className="font-semibold text-sm" style={{ color: colors.darkBrown }}>{s.title}</span>
                            </div>
                            <p className="text-xs" style={{ color: colors.mediumBrown }}>{s.subtitle}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}

                {tab === 'content' && data.sections.map((s) => (
                  <div key={s.id} className="mb-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold" style={{ background: `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})`, color: colors.cream }}>{s.letter}</div>
                      <div>
                        <h3 className="text-lg font-bold" style={{ color: colors.darkBrown }}>{s.title}</h3>
                        <p className="text-sm" style={{ color: colors.mediumBrown }}>{s.subtitle}</p>
                      </div>
                    </div>
                    <div className="rounded-lg p-4" style={{ background: colors.softBeige, borderLeft: `4px solid ${colors.lightBrown}` }}>
                      <p className="text-sm" style={{ color: colors.darkBrown }}><strong>Key Truth:</strong> {s.keyTruth}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between px-6 py-3" style={{ borderTop: `1px solid ${colors.softBeige}` }}>
                {week > 1 && <button className="text-sm flex items-center gap-1" style={{ color: colors.mediumBrown }} onClick={() => navTo('week', week - 1)}><ChevronLeft className="w-4 h-4" />Week {week - 1}</button>}
                {week < 7 && <button className="text-sm flex items-center gap-1 ml-auto" style={{ color: colors.mediumBrown }} onClick={() => navTo('week', week + 1)}>Week {week + 1}<ChevronRight className="w-4 h-4" /></button>}
              </div>
            </>
          )}

          <div className="flex justify-around py-4" style={{ background: colors.white, borderTop: `1px solid ${colors.softBeige}` }}>
            {[
              { s: 'home', icon: Home, label: 'Home' },
              { s: 'weeks', icon: BookOpen, label: 'Weeks' },
              { s: 'community', icon: Users, label: 'Community' },
              { s: 'profile', icon: User, label: 'Profile' },
            ].map(({ s, icon: Icon, label }) => (
              <button key={s} className="flex flex-col items-center gap-1" onClick={() => ['home', 'weeks'].includes(s) && navTo(s)}>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: screen === s || (s === 'weeks' && screen === 'week') ? `linear-gradient(135deg, ${colors.darkBrown}, ${colors.mediumBrown})` : colors.softBeige }}>
                  <Icon className="w-5 h-5" style={{ color: screen === s || (s === 'weeks' && screen === 'week') ? colors.cream : colors.mediumBrown }} />
                </div>
                <span className="text-xs font-semibold" style={{ color: screen === s ? colors.darkBrown : colors.mediumBrown }}>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
